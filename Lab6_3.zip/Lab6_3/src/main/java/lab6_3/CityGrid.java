
package lab6_3;

import java.util.Random;


public class CityGrid {
    
    private int xCoor; // x-Coordinate
    private int yCoor; // y-Coordinate
    private int gridSize; // City Size
    private int move;
    
    public CityGrid(){
        gridSize = 100;
        xCoor = 5;
        yCoor = 5;
}
    Random rand = new Random();
    public void walk(){
        move = rand.nextInt(4);
        switch(move){
            case(0) :
                xCoor++;
                break;
            case(1) :
                xCoor--;
                break;
            case(2) :
                yCoor++;
                break;
            case(3) :
                yCoor--;
                break;
        }
    } //Four direction (y++) (y--) (x--) (x++)
    public boolean isInCity(){
        boolean inCityCheck = true;
        if (xCoor < 0 || xCoor > 10){
            inCityCheck = false;
        }
        if (yCoor < 0 || yCoor > 10){
            inCityCheck = false;
        }
        return inCityCheck;
    } // return if in city
    public void reset(){
        xCoor = 5; yCoor = 5;
    } // reset position to center
    public static void main(String[] args){
        int step = 0;
        int maxStep = 0;
        int allStep = 0;
        double stepAv = 0;
        CityGrid city = new CityGrid();
        for (int i = 0; i < 10000; i++){
            int cnt = 0;
            while(cnt < 1000){
                city.walk();
                if (!city.isInCity()){
                    city.reset();
                    break;
                }
                else{
                 step += 1;
                 cnt += 1;
                } 
            }
            if (step > maxStep){
                maxStep = step;
            }
            allStep += step;
            step = 0;
    }
        stepAv = allStep/10000.0;
        System.out.println("Average number of steps that a person can take and is still in the city: " + stepAv);
        System.out.println("Maximum number of steps that a person can take and is still in the city: "+ maxStep);
    }
}
