
package lab5_1;

import java.lang.String;

public class Zeller {
    
    private int dayOfMonth;
    private int month;
    private int year;
    private int h,q,m,j,k;
    
    public Zeller(int day ,int month ,int year){
        this.dayOfMonth = day;
        this.month = month;
        this.year = year;
    }
    public enum Day{
        SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY;
    }
    
    public Day getDayOfWeek(){
        q = dayOfMonth;
        m = month;
        if (m == 1){
            year -= 1;
            m = 13;
        }
        if (m == 2){
            year -= 1;
            m = 14;
        }
        j = year/100;
        k = year % 100;
        h = (q + (((m + 1)*26)/10) + k + (k/4) + (j/4) + (5*j)) % 7;
        Day dayOut = Day.SUNDAY;
        if (h == 0){
            dayOut = Day.SATURDAY;
        }
        if (h == 1){
            dayOut = Day.SUNDAY;
        }
        if (h == 2){
            dayOut = Day.MONDAY;
        }
        if (h == 3){
            dayOut = Day.TUESDAY;
        }
        if (h == 4){
            dayOut = Day.WEDNESDAY;
        }
        if (h == 5){
            dayOut = Day.THURSDAY;
        }
        if (h == 6){
            dayOut = Day.FRIDAY;
        }
        return dayOut;
        
    }
}
