
package com.mycompany.lab11_2;


public interface CanFly {
    void fly(Terrain terrain);
}
