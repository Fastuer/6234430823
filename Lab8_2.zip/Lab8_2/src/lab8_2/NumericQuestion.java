
package lab8_2;


public class NumericQuestion extends Question{
    public NumericQuestion(String quest){
        super.setText(quest);
    }
    @Override
    public boolean checkAnswer(String response){
        double resp = Double.valueOf(response);
        double ans = Double.valueOf(super.getAnswer());
        double different = Math.abs(resp - ans);
        return different <= 0.01;
    }
}
