
package lab8_2;

import java.util.ArrayList;


public class ChoiceQuestion extends Question{
    
    ArrayList<String> choice = new ArrayList<String>();
    
    public ChoiceQuestion(String question){
        super.setText(question);
    }
    // add choice in choice ArrayList if correct == true choice.setAnswer
    public void addChoice(String choice, boolean correct){
        this.choice.add((this.choice.size()+1)+": "+choice);
        if (correct) super.setAnswer(Integer.toString(this.choice.size()));
    }
    @Override
    public void display(){
        System.out.println(super.getText());
        for (int i = 0; i < choice.size(); i++ ){
            System.out.println(choice.get(i));
        }
    }
    @Override
    public boolean checkAnswer(String response){
        return response.equals(super.getAnswer());
    }
}
