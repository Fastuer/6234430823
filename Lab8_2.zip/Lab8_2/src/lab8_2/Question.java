
package lab8_2;


public class Question {

    String text; //question
    String answer; //answer
    
    public Question(){
        text = null;
        answer = null;
    }
    public Question(String message){
        this.text = message;
    }
    //set question
    public void setText(String quest){
        text = quest;
    }
    public String getText(){
        return text;
    }
    //set answer
    public void setAnswer(String ans){
        answer = ans;
    }
    public String getAnswer(){
        return answer;
        
    }
    public boolean checkAnswer(String response){
        return (response.equals(answer));
    }
    public void display(){
        System.out.println(text);
    }
}
