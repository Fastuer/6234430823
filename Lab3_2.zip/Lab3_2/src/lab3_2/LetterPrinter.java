
package lab3_2;

public class LetterPrinter {
     public static void main(String[] args)
    {
        Letter message1 = new Letter("Jade","Clarissa");
        message1.addLine("We must find Simon quickly.");
        message1.addLine("He might be in danger.");
        System.out.println("Dear "+message1.getText());

    }
}
