
package lab3_2;


public class Letter {

    private String sender;
    private String reciver;
    private String message = "";
    public Letter(String from, String to){
        sender = from +":"+"\n";
        reciver = "\n" + to ;
    }
    public void addLine(String line){
        message = message + line + "\n"  ;
    }
    public String getText(){
        return sender +"\n"+ message +"\n"+"Sincerely,"+"\n"+ reciver;
    }
    
}
