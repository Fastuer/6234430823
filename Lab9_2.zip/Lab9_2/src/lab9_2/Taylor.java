
package lab9_2;


public abstract class Taylor {
    private int k;
    private double x;
    
    public Taylor(int k, double x){
        this.k = k;
        this.x = x;
    }
    private int fac = 1;
    public int factorial(int n){
        if (n == 0) n = 1;
        for (int i = n; i > 1; i--){
            fac *= (i);
        }
        n = fac;
        fac = 1;
        return n;
    }
    public void setlter(int k){
        this.k = k;
    }
    public int getlter(){
        return k;
    }
    public void setValue(double x){
        this.x = x;
    }
    public double getValue(){
        return x;
    }
    public abstract void printValue();
    public abstract double getApprox();
}

