
package lab9_2;


public class expo extends Taylor{
    
    private double approx = 0;
    
    public expo(int k, double x){
        super(k,x);
        setlter(k);
        setValue(x);
    }
    @Override
    public void printValue(){
        System.out.println("Value from Math.exp() is " + Math.exp(getValue()) + ".");
        System.out.println("Approximated value is " + getApprox()+".");
    }
    @Override
    public double getApprox(){
        for (int n = 0; n <= getlter(); n++){ 
            approx += Math.pow(getValue(), n)/factorial(n);
        }
        return approx;
    }
}
