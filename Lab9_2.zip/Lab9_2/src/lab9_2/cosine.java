
package lab9_2;


public class cosine extends Taylor{
    
    private double approx = 0;
    
    public cosine(int k, double x){
        super(k,x);
        setlter(k);
        setValue(x);
    }
    @Override
    public void printValue(){
        System.out.println("Value from Math.exp() is " + Math.exp(getValue()) + ".");
        System.out.println("Approximated value is " + getApprox()+".");
    }
    @Override
    public double getApprox(){
        for (int n = 0; n <= getlter(); n++){
            approx += ((Math.pow(-1, n)*Math.pow(getValue(), 2*n))/(factorial(2*n)));
        }
        return approx;
    }
}
