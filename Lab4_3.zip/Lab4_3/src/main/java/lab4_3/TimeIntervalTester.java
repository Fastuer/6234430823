
package lab4_3;
import java.util.Scanner;
public class TimeIntervalTester {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter start time: ");
        int num = sc.nextInt();
        Scanner sc2 = new Scanner(System.in);
        System.out.print("Enter final time: ");
        int num2 = sc.nextInt();
        TimeInterval allTime_h = new TimeInterval(num,num2);
        TimeInterval allTime_m = new TimeInterval(num,num2);
        System.out.println(allTime_h.getHours() + " hours" + " " + allTime_m.getMinutes() + " minutes");
    }
}
