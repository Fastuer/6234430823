
package lab4_3;


public class TimeInterval {
    private int time_i;
    private int time_f;
    private int hours_diff;
    private int minutes_diff;
    public TimeInterval(int time_i, int time_f){
        this.time_i = time_i;
        this.time_f = time_f;
    }
    public int getHours(){
        time_i = (int) Math.floor(((time_i/100)*60) + (time_i%100));
        time_f = (int) Math.floor(((time_f/100)*60) + (time_f%100));
        hours_diff = ((Math.abs(time_i - time_f))/60);
        return hours_diff;
    }
    public int getMinutes(){
        time_i = (int) Math.floor(((time_i/100)*60) + (time_i%100));
        time_f = (int) Math.floor(((time_f/100)*60) + (time_f%100));
        minutes_diff = ((Math.abs(time_i - time_f))%60);
        return minutes_diff;
    }
}
