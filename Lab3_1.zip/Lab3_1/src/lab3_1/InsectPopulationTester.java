
package lab3_1;


public class InsectPopulationTester {
    public static void main(String[] args){
        InsectPopulation insect = new InsectPopulation(10);
        insect.breed();
        insect.spray();
        System.out.println("Number of insect:" + insect.getNumInsect());
        insect.breed();
        insect.spray();
        System.out.println("Number of insect:" + insect.getNumInsect());
        insect.breed();
        insect.spray();
        System.out.println("Number of insect:" + insect.getNumInsect());
    }
}
