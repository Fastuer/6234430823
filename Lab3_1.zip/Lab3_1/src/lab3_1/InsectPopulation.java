
package lab3_1;

public class InsectPopulation {

    
    private double total;
    public InsectPopulation(double insect_i){
        total = insect_i;      
    }
    public void breed(){
        total = total * 2;
    }
    public void spray(){
        total = total * 0.9;   
    }
    public double getNumInsect(){
        return total;
    }
    
}
