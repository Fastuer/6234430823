
package Lab10_1;


public class Subject implements Evaluation{
    
    private String subjName;
    private int[] score;
    private double avgScore = 0;
    private int sum_score = 0;
    
    public Subject(String subjName, int[] score){
        this.subjName = subjName;
        this.score = score;
    }
    @Override
    public double evaluate(){
        for (int i = 0; i < score.length; i++){
            sum_score = sum_score + score[i];
        }
        avgScore = sum_score/score.length;
        return avgScore;
    }
    @Override
    public char grade(double avgScore){
        if (avgScore >= 70) return 'P';
        else return 'F';
    }
    @Override
    public String toString(){
        return subjName;
    }
}
