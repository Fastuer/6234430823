
package Lab10_1;


public class Secretary extends Employee implements Evaluation{
    
    private int typingSpeed;
    private int[] score;
    private int sum_score = 0;
    
    public Secretary(String name, int salary, int[] score, int speed){
        super(name, salary);
        this.typingSpeed = speed;
        this.score = score;
    }
    @Override
    public double evaluate(){
        for (int i = 0; i < score.length; i++){
        sum_score = sum_score + score[i];
    }
        return sum_score;
    }
    @Override
    public char grade(double sum_score){
        if (sum_score >= 90){
            super.setSalary(18000);
            return 'P';
        } else {
            return 'F';
        }
    }
    
}
