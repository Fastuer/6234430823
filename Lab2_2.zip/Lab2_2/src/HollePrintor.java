/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usci
 */
public class HollePrintor {

 
    public static void main(String[] args) {
        String S1 = "Hello, World";
        String S2 = S1.replace("o", "a").replace("e", "o").replace("a","e");
        System.out.println(S2);
    }
    
}
