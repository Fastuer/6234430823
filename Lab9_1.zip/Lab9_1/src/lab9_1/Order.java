
package lab9_1;

import java.util.ArrayList;


public class Order {

    public static int cntOrder = 0; // for auto gnerate id of order sheet
    private int id;
    private Customer c;
    private ArrayList<Pizza> p = new ArrayList<Pizza>();
    
    public Order(Customer c){
        this.c = c;
    }
    public void addPizza(Pizza pizzaType){
        this.p.add(pizzaType);
    }
    public String getOrderDetail(){
        cntOrder ++;
        id = cntOrder;
        System.out.println("Order id : " + id);
        System.out.println(c.toString());
        for (int i = 0; i < p.size(); i++){
            System.out.println(p.get(i).toString());
        }
        return "Total pieces : " + p.size();
    }  
    private double total = 0;
    public double calculatePayment(){
        for (int i = 0; i < p.size(); i++){
            total += p.get(i).getPrice();
        }
        System.out.println("Total cost : " + (total - (total*c.getDiscount()/100.0)));
        return (total - (total*c.getDiscount()/100.0));
    }
}
