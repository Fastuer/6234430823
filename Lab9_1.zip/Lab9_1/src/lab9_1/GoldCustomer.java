
package lab9_1;


public class GoldCustomer extends Customer{
    
    private double discount;
    
    public GoldCustomer(String customerName, String customerTel, int discount){
        super(customerName, customerTel);
        this.discount = discount;
    }
    @Override
    public String toString(){
        return super.toString() + " discount : " + discount;
    }
    @Override
    public double getDiscount(){
        return discount;
    }
}
