
package lab9_1;


public class Pizza {
    
    private String name;
    private double price;
    
    public Pizza(){
        name = null; price = 0;
    }
    public Pizza(String pizzaName, int pizzaPrice){
        this.name = pizzaName;
        this.price = pizzaPrice;
    }
    @Override
    public String toString(){
        return name + " price : " + price;
    }
    public double getPrice(){
        return price;
    }
}
