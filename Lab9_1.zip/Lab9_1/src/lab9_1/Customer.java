
package lab9_1;


public class Customer {
    
    private String name,tel;
    
    public Customer(){
        name = null; tel = null;
    }
    public Customer(String customerName, String customerTel){
        this.name = customerName;
        this.tel = customerTel;
    }
    @Override
    public String toString(){
        return name + " tel : " + tel;
    }
    public double getDiscount(){
        return 0;
    }
    
    
    
    
}
