
package lab9_1;


public class PizzaSpecial extends Pizza {
    
    private String special;
    
    public PizzaSpecial(String pizzaName, int pizzaPrice, String pizzaSpecial){
        super(pizzaName,pizzaPrice);
        this.special = pizzaSpecial;
    }
    @Override
    public String toString(){
        return super.toString() + " special : " + special;
    }
    
}
