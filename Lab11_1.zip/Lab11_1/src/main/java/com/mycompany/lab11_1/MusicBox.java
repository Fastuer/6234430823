
package com.mycompany.lab11_1;

import java.util.ArrayList;


public class MusicBox implements SimpleQueue{
    
    private ArrayList<String> playList = new ArrayList<>();
    
    public MusicBox(){
        this.playList = playList;
    }
    @Override
    public void enqueue(Object o){
        playList.add(o.toString());
        System.out.println(o + " is added in queue");
    }
    @Override
    public void dequeue(){
        System.out.println("Now playing " + playList.get(0));
        playList.remove(0);
    }
}
