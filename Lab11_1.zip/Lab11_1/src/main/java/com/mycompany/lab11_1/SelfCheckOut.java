
package com.mycompany.lab11_1;

import java.util.ArrayList;


public class SelfCheckOut implements SimpleQueue{
    
    private ArrayList<Product> goods = new ArrayList<Product>();
    private double amount;
    private int cnt = 0;
    
    public SelfCheckOut(){
        this.goods = goods;
    }
    @Override
    public void enqueue(Object o){
        goods.add((Product) o);
        System.out.println((goods.get(cnt)).getName() + " is added in queue");
        cnt++;
    }
    @Override
    public void dequeue(){
        amount += (goods.get(0)).getPrice();
        goods.remove(0);
    }
    public double getAmount(){
        return amount;
    }
}
