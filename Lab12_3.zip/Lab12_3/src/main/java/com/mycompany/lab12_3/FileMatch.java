
package com.mycompany.lab12_3;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;


public class FileMatch {
    
    public static void main(String[] args){
        try {
            //read mster.txt
            File master = new File("master.txt");
            Scanner readMas = new Scanner(master);
            ArrayList<AccountRecord> accRec = new ArrayList<>();
            while (readMas.hasNextLine() && readMas.hasNext()){
                int accNoR = readMas.nextInt();
                String name = readMas.next();
                String name2 = readMas.next();
                double balance = readMas.nextDouble();
                AccountRecord acct = new AccountRecord(accNoR, name + " " + name2, balance);
                accRec.add(acct);
            }
            //read trans.txt
            File trans = new File("trans.txt");
            Scanner readTrans = new Scanner(trans);
            ArrayList<TransactionRecord> transRec = new ArrayList<>();
            while(readTrans.hasNextLine() && readTrans.hasNext()){
                int accNoT = readTrans.nextInt();
                double aot = readTrans.nextDouble();
                TransactionRecord t = new TransactionRecord(accNoT, aot);
                transRec.add(t);
            }
            
            for (int i = 0; i < transRec.size(); i++){
                for (int j = 0; j < accRec.size(); j++){
                    if (transRec.get(i).getAcctNo() == accRec.get(j).getAcctNo()){
                        accRec.get(j).combine(transRec.get(i));
                    }
                }
            }
            try (RandomAccessFile newMaster = new RandomAccessFile("newMaster.dat", "rw")) {
                for (int i = 0; i < accRec.size(); i++){
                    AccountRecord eAcct = accRec.get(i);
                    String masterName = eAcct.getName();
                    for (int j = 1; j <= 30 - eAcct.getName().length(); j++ ){
                        masterName += " ";
                    }
                    newMaster.writeInt(eAcct.getAcctNo());
                    newMaster.writeChars(masterName);
                    newMaster.writeDouble(eAcct.getBalance());
                    newMaster.writeInt(eAcct.getTransCnt());
                }
                int total_acc = 0;
                double total_balance = 0;
                int no_trans = 0;
                for(int i = 0; i < newMaster.length(); i += 76){
                    total_acc ++;
                    //System.out.println(i);
                    newMaster.seek(i + 64);
                    total_balance += newMaster.readDouble();
                    if (newMaster.readInt() == 0) no_trans++;
                }
                System.out.println(newMaster.length());
                System.out.println("Total Account Record : " + total_acc);
                System.out.println("Total balance : " + total_balance);
                System.out.println("No transaction : " + no_trans);
            }
        } 
        catch (IOException e){
            System.out.println(e);
        } 
    }
    
}
