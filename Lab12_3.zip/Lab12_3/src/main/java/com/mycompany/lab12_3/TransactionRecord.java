
package com.mycompany.lab12_3;


public class TransactionRecord {
    
    private int acctNo;
    private double aot;
    
    public TransactionRecord(int acctNo, double aot){
        this.acctNo = acctNo;
        this.aot = aot;
    }
    public int getAcctNo(){ return acctNo; }
    public double getAot(){ return aot; }
}
