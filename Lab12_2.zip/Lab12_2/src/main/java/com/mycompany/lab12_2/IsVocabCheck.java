
package com.mycompany.lab12_2;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class IsVocabCheck {
    
    public static void main(String[] args){
        
        File wordlist = new File("wordlist.txt");
        ArrayList<String> vocab = new ArrayList<>();
        
        try{
            Scanner read = new Scanner(wordlist);
            while (read.hasNextLine()){
                String word = read.nextLine();
                vocab.add(word);
            }
            Scanner word_in = new Scanner(System.in);
            System.out.print("Enter a sentence: ");
            String word_check = word_in.nextLine();
            String[] word_split = word_check.split(" ");
            ArrayList<String> search = new ArrayList<>(); 
            search.addAll(Arrays.asList(word_split));
            int cnt = 0;
            for (int i = 0; i < word_split.length; i++){
                for (int j = 0; j < vocab.size(); j++){
                    if ((word_split[i]).equals((vocab.get(j)))) {
                        search.remove(search.get(i-cnt));
                        cnt++;
                    }
                }
            }
            if (search.isEmpty()) System.out.println("Words not contained:\nN/A");
            else {
               System.out.println("Words not contained: ");
                for (int k = 0; k < search.size(); k++){
                System.out.println(search.get(k));
                }
            }
            }
        catch(IOException e){
            System.out.println(e);
        }
    }
}
