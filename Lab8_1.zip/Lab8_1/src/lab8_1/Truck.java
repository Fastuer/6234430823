
package lab8_1;


public class Truck extends Car {
    
    private  double M_weight;
    private double weight;
    
    public Truck(double gas, double efficiency, double weight, double M_weight){
        super(gas,efficiency);
        this.M_weight = M_weight;
        this.weight = weight;
        if (weight > M_weight) this.weight = M_weight;
    }
    @Override
    public void drive(double distance){
        if ((distance/efficiency) >= getGas()) System.out.println("You cannot drive too far, please add gas.");
        else if (weight < 1) gas -= distance/efficiency;
        else if (weight >= 1 && weight < 10) gas -= ((distance/efficiency)+((distance/efficiency)*(10.0/100.0)));
        else if (weight >= 11 && weight < 20) gas -= ((distance/efficiency)+((distance/efficiency)*(20.0/100.0)));
        else if (weight > 20) gas -= ((distance/efficiency)+((distance/efficiency)*(30.0/100.0)));          
    }
    
}
