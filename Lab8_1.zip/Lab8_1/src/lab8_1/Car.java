
package lab8_1;


public class Car {
    
    public double gas;
    public double efficiency;
    
    public Car(){
        gas = 0;
        efficiency = 0;
    }
    public Car(double gas, double efficiency){
        this.gas = gas;
        this.efficiency = efficiency;
    }
    public void drive(double distance){
        gas = getGas();
        efficiency = getEfficiency();
        if (getGas() < (distance/efficiency)){
            System.out.println("You can not drive too far, please add gas");
        }else{
            gas -= distance/efficiency;
        }
    }
    public void setGas(double amount){
         this.gas = amount;
    }
    public double getGas(){
        return gas;
    }
    public double getEfficiency(){
        return efficiency;
    }
    public void addGas(double amount){
        this.gas += amount;
    }
    
}

