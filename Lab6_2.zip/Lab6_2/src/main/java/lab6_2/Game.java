
package lab6_2;

import java.util.Random;
import java.util.Scanner;


public class Game {
    
   String player;
   String ui;
   public int uiScore;
   public int playerScore;
   public boolean winCheck = true;
   public boolean checkInput = true; 
   
    public void play(){
        Scanner user_in = new Scanner(System.in);
        Random rand = new Random();
        while (winCheck){
            while (checkInput){
                System.out.println("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS : ");
                player = user_in.next();
                if (player.equals("0") || player.equals("1") || player.equals("2") ){
                    checkInput = false;
                }
            }
        //play method
            switch (player){
                case "0" :
                    System.out.println("You enter: ROCK");
                    break;
                case "1" :
                    System.out.println("You enter: PAPER");
                    break;
                case "2" :
                    System.out.println("You enter: SCISSORS");
                    break;
                }
            ui = Integer.toString(rand.nextInt(3));
            switch (ui){
                case "0" :
                    System.out.println("Computer: ROCK");
                    break;
                case "1" :
                    System.out.println("Computer: PAPER");
                    break;
                case "2" :
                    System.out.println("Computer: SCISSORS");
                    break;
            }
            if (player.equals("0")){
                if (ui.equals("0")){
                    System.out.println("it's a tie.");
                    checkInput = true;
                }
                if (ui.equals("1")){
                    System.out.println("You lose!");
                    uiScore += 1;
                    checkInput = true;
                }
                if (ui.equals("2")){
                    System.out.println("You win!");
                    playerScore += 1;
                    checkInput = true;
                }
            }
            if (player.equals("1")){
                if (ui.equals("0")){
                    System.out.println("You win!");
                    playerScore += 1;
                    checkInput = true;
                }
                if (ui.equals("1")){
                    System.out.println("it's a tie.");
                    checkInput = true;
                }
                if (ui.equals("2")){
                    System.out.println("You lose!");
                    uiScore += 1;
                    checkInput = true;
                }
            }
            if (player.equals("2")){
                if (ui.equals("0")){
                    System.out.println("You lose!");
                    uiScore += 1;
                    checkInput = true;
                }
                if (ui.equals("1")){
                    System.out.println("You win!");
                    playerScore += 1;
                    checkInput = true;
                }
                if (ui.equals("2")){
                    System.out.println("it's a tie.");
                    checkInput = true;
                }
            }
            if (Math.abs(playerScore - uiScore) == 2){
                if (playerScore > uiScore){
                    System.out.println("-------------------------------------");
                    System.out.println("Congrats! You win.");
                    System.out.println("User Score:" + playerScore);
                    System.out.println("Computer Score:" + uiScore);
                    winCheck = false;
                }   //player win
                if (playerScore < uiScore){
                    System.out.println("-------------------------------------");
                    System.out.println("Too bad! You lose.");
                    System.out.println("User Score:" + playerScore);
                    System.out.println("Computer Score:" + uiScore);
                    winCheck = false;
                }   //player lose
            }
        }
    }
}
