
package lab7_1;


public class PurseTester {

    
    public static void main(String[] args) {
        Purse purse_a = new Purse();
        Purse purse_b = new Purse();
        purse_a.addCoin("Quarter");
        purse_a.addCoin("Dime");
        purse_a.addCoin("Nickel");
        purse_a.addCoin("Dime");
        purse_b.addCoin("Quarter");
        purse_b.addCoin("Dime");
        purse_b.addCoin("Nickel");
        purse_b.addCoin("Dime");
        purse_a.reverse();
        System.out.println(purse_a.toString());
        System.out.println(purse_b.toString());
        System.out.println(purse_a.sameCoins(purse_b));
        System.out.println(purse_a.sameContents(purse_b));
    }
    
}
