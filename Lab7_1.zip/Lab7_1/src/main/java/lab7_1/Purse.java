
package lab7_1;

import java.util.ArrayList;

public class Purse {
    
    private ArrayList<String> purse_1;
    
    public Purse(){
        purse_1 = new ArrayList<String>(); 
    }
    public void addCoin(String coinName){
        purse_1.add(coinName);
    }
    public String toString(){
        String purseOut = "";
        for (int i = 0; i < purse_1.size(); i ++){
            purseOut += purse_1.get(i);
            if ( i < purse_1.size() - 1) purseOut += ",";
        }
        return "Purse[" + purseOut + "]";
    }
    public ArrayList<String> reverse(){
        ArrayList<String> purse_2 = new ArrayList<String>();
        for(int i = purse_1.size()-1;i >= 0 ; i--){
             purse_2.add(purse_1.get(i));
        }
        purse_1 = purse_2;
        return purse_1;
    }
    public void transfer(Purse other){
        int c_size = purse_1.size();
         for(int i = 0; i < c_size ; i++){
            other.purse_1.add(purse_1.get(0));
            purse_1.remove(0);
         }
    }
    public boolean sameContents(Purse other){
        boolean check =true;
        if(other.purse_1.size()!= purse_1.size()) check =false;
        else for (int i = 0 ; i < purse_1.size() ; i++){
            if (!other.purse_1.get(i).equals(this.purse_1.get(i))){
                check = false;
                break;
            } 
        }
        return check;
    }
    public boolean sameCoins(Purse other){
        boolean check = true;
        if (other.purse_1.size()!= purse_1.size()) check =false;
        else for (int i = 0 ; i < purse_1.size() ; i++){
            int coin1 = 0;
            int coin2 = 0;
            for (int j = 0 ; j < purse_1.size() ; j++){
                if (purse_1.get(i).equals(purse_1.get(j)))
                    coin1++;
                if(purse_1.get(i).equals(other.purse_1.get(j)))
                    coin2++;
            }
            if(coin1 != coin2){
                check = false;
                break;
            }
        }
        return check;
    }
}
