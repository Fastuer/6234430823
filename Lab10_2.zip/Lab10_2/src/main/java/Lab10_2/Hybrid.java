
package Lab10_2;


public class Hybrid extends Bus implements Electric,LiquidFuel{
    
    private double voltage;
    private double range;
    private int emissionTier;
    
    public Hybrid(int range, int emissionTier, double voltage, int capacity, double cost){
        super(capacity, cost);
        this.range = range;
        this.emissionTier = emissionTier;
        this.voltage = voltage;
    }
    @Override
    public double getVoltage(){
        if(voltage <= LOW_VOLTAGE) voltage = LOW_VOLTAGE;
        if(voltage >= HIGH_VOLTAGE) voltage = HIGH_VOLTAGE;
        return voltage;
    }
    @Override
    public double getRange(){
        return range;
    }
    @Override
    public int getEmissionTier(){
        return emissionTier;
    }
    @Override
    public double getAccel(){
        return 4.0;
    }
}
