
package Lab10_2;

import java.util.ArrayList;


public class BusTester {

    
    public static void main(String[] args) {
        ArrayList<Bus> arr = new ArrayList<Bus>();
        arr.add(new Hybrid(150, 1, 600, 45, 1.2));
        arr.add(new CNGBus(200, 2, 50, 1));
        for (int i = 0; i < arr.size(); i++){
            System.out.println("ID: " + arr.get(i).getID());
            if (arr.get(i) instanceof Hybrid){
                System.out.println("Emission Tier: " + ((Hybrid)arr.get(i)).getEmissionTier());
            }
            if (arr.get(i) instanceof CNGBus){
                System.out.println("Emission Tier: " + ((CNGBus)arr.get(i)).getEmissionTier());
            }
            System.out.println("Accel: " + arr.get(i).getAccel());
        }
    }
    
}
