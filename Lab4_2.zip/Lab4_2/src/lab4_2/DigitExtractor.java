
package lab4_2;

public class DigitExtractor {
    
    private int integer;
    private int modInt;
    
public DigitExtractor(int anInteger){
        this.integer = anInteger;
    }
    public int nextDigit(){
        modInt = integer%10;
        integer = integer/10;
        return modInt;
    }
    
}
