/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_3;

import java.util.Calendar;
import java.util.GregorianCalendar;
public class Lab2_3 {

    
    public static void main(String[] args) {
        GregorianCalendar cal = new GregorianCalendar();
        GregorianCalendar myBirthday = new GregorianCalendar(1990,Calendar.MARCH, 12);
        cal.add(Calendar.DAY_OF_MONTH, 100);
        myBirthday.add(Calendar.DAY_OF_MONTH, 10000);
        int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
        int month = cal.get(Calendar.MONTH)+1;
        int year = cal.get(Calendar.YEAR);
        int weekday = cal.get(Calendar.DAY_OF_WEEK);
        System.out.println(weekday+" "+dayOfMonth+" "+month+" "+year);
        dayOfMonth = myBirthday.get(Calendar.DAY_OF_MONTH);
        month = myBirthday.get(Calendar.MONTH)+1;
        year = myBirthday.get(Calendar.YEAR);
        weekday = myBirthday.get(Calendar.DAY_OF_WEEK);
        System.out.println(weekday+" "+dayOfMonth+" "+month+" "+year);
    }
    
}
