
package lab6_1;


public class CannonBall {

    private double initV;
    private double simS;
    private double simT;
    private double cal_s;
    private double cal_v;
    public static final double g = 9.81;
    
    public CannonBall(double v) {
        this.initV = v;
        cal_v = v;
    }
    public void simulatedFlight(){
        int time = 0;
        while(initV >= 0){
        simS += initV * 0.01;
        initV -= g*0.01;
        time += 1;
            if (time%100 == 0 ){
                System.out.printf("Distance on %.0f sec: %.3f\n",simT,simS);
            }
            simT = time/100.0;
        }
    }       
    public double calculusFlight(double t){
        cal_s = (-0.5*g*t*t) + (cal_v*t);
        return cal_s;
    }
    public double getSimulatedTime(){
        return simT;
    }
    public double getSimulatedDistance(){
        return simS;
    }
}
