
package lab6_1;


public class CannonBallTester {

    
    public static void main(String[] args) {
        CannonBall ball = new CannonBall(100);
        ball.simulatedFlight();
        System.out.printf("Final distance: %.3f Total time: %.2f\nDistance from calculus"
                + "equation: %.3f\n",ball.getSimulatedDistance(),ball.getSimulatedTime()
                ,ball.calculusFlight(ball.getSimulatedTime()));
    }
    
}
