
package Lab3_3;

public class CashRegister {
    public double tax;
    public double price;
    public double balance;
    public double change;
    public double taxTotal;
    
    public CashRegister(double taxRate){
        this.tax = taxRate;
    }
    public void enterPayment(double money){
        balance += money;
    }
    public void recordPurchase(double goodPrice){
        price += goodPrice;
    }
    public void recordTaxablePurchase(double goodPrice){
        price += goodPrice + (goodPrice*(tax/100.0));
        taxTotal += (goodPrice*(tax/100.0));
    }
    public double getTotalTax(){
        return taxTotal;
    }
    public double giveChange(){
        change = balance - price;
        change = (Math.round(change*10.0))/10.0;
        return change;
    }
}
