
package Lab3_3;

public class CashRegisterTester {
    public static void main(String[] args){
        CashRegister cashRegis = new CashRegister(7);
        cashRegis.enterPayment(100);
        cashRegis.recordPurchase(50);
        cashRegis.recordPurchase(10);
        cashRegis.recordTaxablePurchase(20);
        System.out.println("Your change is " + cashRegis.giveChange());
    }
}
