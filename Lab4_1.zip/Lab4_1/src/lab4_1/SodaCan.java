
package lab4_1;

public class SodaCan {
    
    public float height;
    private float diameter;
    private float volume;
    private float surface;
    private float radius; 
    public SodaCan(float height, float diameter){
        this.diameter = diameter;
        this.height = height;        
}
    public float getVolume(){
        radius = (diameter/2);
        volume = (float) ((Math.PI)*(Math.pow(radius,2))*height);
        volume = Math.round(volume*100.0);
        volume = (float) (volume/100.0);
        return volume;
    }
    public float getSurfaceArea(){
        surface = (float) (((Math.PI)*(Math.pow(radius,2))*2)+((Math.PI)*2*radius*height));
        surface = Math.round(surface*100.0);
        surface = (float) (surface/100.0);
        return surface;
    }
    public float getHeight(){
        return height;
    }
    public float getDiameter(){
        return diameter;
    }
    
}
