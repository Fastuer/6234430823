
package lab4_1;


public class SodaTester {

    
    public static void main(String[] args) {
        SodaCan var = new SodaCan(15,5);
        System.out.println("Enter height: " + Math.round(var.getHeight()));
        System.out.println("Enter diameter: " + Math.round(var.getDiameter()));
        System.out.println("Volume: " + var.getVolume());
        System.out.println("Surface Area: " + var.getSurfaceArea());
    }
    
}
