
package com.mycompany.lab12_1;

import java.io.*;
import java.util.Scanner;

public class Sequential {
    
    public static void main(String[] args) throws FileNotFoundException{
        
        File file = new File("text.txt");
        //input data to file
        Scanner inText = new Scanner(System.in);
        PrintWriter type = new PrintWriter(file);
        System.out.println("Type here : ");
        String str = inText.nextLine();
        while (!str.equals("quit")){
            type.println(str);
        str = inText.nextLine();
        }
        type.close();
        //read data
        int char_cnt = 0;
        int line_cnt = 0;
        int word_cnt = 0;
        Scanner read = new Scanner(file);
        while (read.hasNextLine()){
            String line = read.nextLine();
            char_cnt += line.length();
            line_cnt ++;
            String[] word_split = line.split(" ");
            word_cnt += word_split.length;
        }
        System.out.println("Total characters : " + char_cnt);
        System.out.println("Total words : " + word_cnt);
        System.out.println("Total lines : " + line_cnt);
        read.close();
    }
}
